<?php
$servername = "lab-db.cwudv2dxb84u.us-east-1.rds.amazonaws.com";
$username = "admin";
$password = "lab-password";
$dbname = "awsDAW";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexion fallida: " . $conn->connect_error);
}
echo "Conexión exitosa";

$conn->close();
?>